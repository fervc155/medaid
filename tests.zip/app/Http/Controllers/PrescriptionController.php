<?php

namespace App\Http\Controllers;

use App\Prescription;
use Illuminate\Http\Request;

class PrescriptionController extends Controller
{
    //Creo que no implementaremos esto, familia
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Prescription $prescription)
    {
        //
    }

    public function edit(Prescription $prescription)
    {
        //
    }

    public function update(Request $request, Prescription $prescription)
    {
        //
    }

    public function destroy(Prescription $prescription)
    {
        //
    }
}
