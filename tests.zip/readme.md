**Desarrollador:** 
Josué Renaud Hernández Guzmán

**Nombre de la aplicación:**
(Por definir)

**Propósito de la aplicación:**
Proporcionar a trabajadores del área médica una manera fácil de administrar los doctores que
trabajan para alguna empresa de salud, incluyendo los consultorios en los que trabajan y los
pacientes a los que atienden. La aplicación incluirá también un sistema de citas que los usuarios 
podrán utilizar para programar citas para los doctores de la empresa.

También se podrán administrar los pacientes, los tratamientos que se le dan a cada uno, y otra
información que se considere relevante a lo largo del desarrollo de la aplicación.
