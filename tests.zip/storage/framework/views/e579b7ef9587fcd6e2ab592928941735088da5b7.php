<?php $__env->startSection('content'); ?>

<!-- 

<div class="contenedor">

<div class="contenedor-titulo hidden-lg-down">
    
    <section class="container m-0  p-0">

        <div class="row contenedor-titulo align-items-center">
            <div class="col ">

                <h1 class="display-4 text-capitalize  text-center"><?php echo e($doctor->name); ?></h1> 
                <h3 class="text-center text-capitalize">Medico</h3>
                
            </div>
        </div>



    </section>
</div>

<div class="contenedor-fondo">
    
</div>

<div class="contenedor-imagen">
    
    <div class="container-fluid mt-0  p-0">

        <div class="row ">
            <div class="col ">

                <img src="<?php echo e(asset('splash/header/doctor.jpg')); ?>"> 
                
            </div>
        </div>



    </div>
</div>

</div>  -->



<div class="tabmenu ">


	<ul class="nav  md-tabs   d-flex  justify-content-center flex-wrap" id="Tabmenu" role="tablist">
		<li>
			<a class="nav-link active " id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
			aria-selected="false"><i class="fas fa-user-md"></i><span> Mis Datos</span></a>
		</li>
		<li>
			<a class="nav-link" id="citas-tab" data-toggle="tab" href="#citas" role="tab" aria-controls="citas"
			aria-selected="true"><i class="fas fa-book"></i><span> Mis Citas</span></a>
		</li>
		<li>
			<a class="nav-link " id="paciente-tab" data-toggle="tab" href="#pacientes" role="tab" aria-controls="pacientes"
			aria-selected="false"><i class="fas fa-user-injured"></i><span> Mis Pacientes</span></a>
		</li>
	</ul>
</div>



<div class="container mt-5">
	
<div class="tab-content ">

	<div class="tab-pane   fade show " id="citas" role="tabpanel" aria-labelledby="citas-tab">

		<div class="row">


			<div class="col tarjeta">

				<div class="row ">
					<section class="col-12 pb-3">
						<h5 class="text-center  text-capitalize"><i class="fas fa-book"></i> Citas pendientes</h5>
					</section>
				</div>
				<div class="row tarjeta-contenido-blanco">
					<div class="col-12 p-0 ">



						<table class="table ">
							<thead>
								<tr>
									<th>Fecha</th>
									<th>Hora</th>
									<th>Costo</th>
									<th>Razón</th>
									<th>Paciente</th>
									<th>Consultorio</th>
									<th>Atender</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($a->completed == false): ?>
								<tr>
									<td><a class="link" href="/appointment/<?php echo e($a->id); ?>"><?php echo e($a->date); ?></a></td>
									<td><?php echo e($a->time); ?></td>
									<td><?php echo e($a->cost); ?></td>
									<td><?php echo e($a->description); ?></td>
									<td><?php echo e($a->patient->name); ?></td>
									<td><a class="link" href="/office/<?php echo e($a->office->id); ?>"><?php echo e($a->office->name); ?></a></td>
									<td>
										<?php echo Form::open(['action' => ['AppointmentController@complete', $a->id], 'method' => 'PATCH']); ?>

										<?php echo e(Form::hidden('_method', 'PATCH')); ?>

										<?php echo e(Form::submit('Atender', ['class' => 'btn btn-success'])); ?>

										<?php echo Form::close(); ?>

									</td>
								</tr>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>





					</div> 

				</div> 

			</div>
		</div>




	</div>

	<div class="tab-pane fade " id="pacientes" role="tabpanel" aria-labelledby="paciente-tab">

		<div class="container">
			<div class="row">

				<div class="col  tarjeta ">
					<div class="row ">
						<div class="col pb-3">


							<h5 class="text-center text-capitalize"><i class="fas fa-user-injured"></i> Pacientes</h5>
						</div>
					</div>

					<div class="row tarjeta-contenido-blanco ">
						<table class="table ">
							<thead>
								<tr>
									<th>DNI</th>
									<th>Nombre</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td> <a class="link" href="/patient/<?php echo e($p->dni); ?>"> <?php echo e($p->dni); ?> </a> </td>
									<td> <a class="link" href="/patient/<?php echo e($p->dni); ?>"> <?php echo e($p->name); ?> </a></td>
								</tr>   
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>


					</div>

				</div> 

			</div>
		</div>

	</div>

	<div class="tab-pane   fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">


		<div class="row ">




			<div class=" col-12 col-md-4">




				<div class="card  lead">


					<div class="rounded">
						<div class="bg-primary text-center p-5">
							<i class="fas fa-user display-1 text-light"></i>
						</div>
					</div>


					<h5 class="card-header h4 text-light bg-secondary text-center text-capitalize"><i class="fas fa-user-md"></i> Datos del médico</h5>

					<div class="card-body">






						<div class="form-inline mb-2">


							<div class="color-principal">

								<i class="fas fa-address-card"></i> ID:
							</div>  

							<?php echo e($doctor->id); ?>


						</div>
						<div class="form-inline mb-2">


							<div class="color-principal">

								<i class="fas fa-phone"></i> Telefono:
							</div>  

							<?php echo e($doctor->telephoneNumber); ?>


						</div>


						<div class="form-inline mb-2">
							<div class="color-principal">
								<i class="fas fa-sun"></i> Turno:
							</div>

							<?php echo e($doctor->turno); ?>


						</div>
						<div class="form-inline mb-2">
							<div class="color-principal">
								<i class="fas fa-birthday-cake"></i> Nacimiento:
							</div>                                  
							<?php echo e($doctor->birthdate); ?>


						</div>



						<div class="form-inline mb-2">
							<div class="color-principal">
								<i class="fas fa-venus-mars"></i> Sexo:
							</div>
							<?php echo e($doctor->sexo); ?>


						</div>


						<div class="form-inline mb-2">
							<div class="color-principal">
								<i class="fas fa-address-card"></i> Celuda: 
							</div>



							<?php echo e($doctor->cedula); ?>



						</div>


						<div class="form-inline mb-3">
							<div class="color-principal">
								<i class="fas fa-user-tie"></i> Especialidad:
							</div>



							<?php echo e($doctor->especialidad); ?>



						</div>  
						<a role="button" class="btn btn-block mt-3  btn-info" href="/doctor/<?php echo e($doctor->id); ?>/edit"> <i class="fas fa-pen"></i> Editar</a>

						<?php echo Form::open(['action' => ['DoctorController@destroy', $doctor->id], 'method' => 'POST']); ?>

						<?php echo e(Form::hidden('_method', 'DELETE')); ?>

						<?php echo e(Form::submit('Eliminar', ['class' => 'btn btn-block mt-3 btn-danger'])); ?>

						<?php echo Form::close(); ?>


					</div>

				</div>

			</div>

			<div class=" col-12 col-md-8">

				<h1 class="text-left h1  text-capitalize color-principal">Medico: <?php echo e($doctor->name); ?></h1>
				<h1 class="text-left h4 text-capitalize color-principal">Datos Generales</h1>


				<div class="contadores d-flex">

					<div class="caja">
						<h3><?php echo e(count($appointments)); ?></h3>
						<p>Citas</p>	
					</div>
					<div class="caja">
						<h3><?php echo e(count($patients)); ?></h3>
						<p>Pacientes</p>
					</div>

				</div>

				
			</div>
		</div>


	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>