<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MedAid</title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('splash/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Bootstrap core JavaScript -->
    

    <!-- Íconos -->
    <link href="<?php echo e(asset('splash/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('splash/vendor/simple-line-icons/css/simple-line-icons.css')); ?>" rel="stylesheet" type="text/css">
    <!-- Fuente -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|Raleway:300,400,500,600,700" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('splash/landing-page.css')); ?>" rel="stylesheet">

    <!-- Data tables -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css')); ?>"/>
    <link href="<?php echo e(asset('splash/default.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('splash/default.time.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('splash/default.date.css')); ?>" rel="stylesheet">
     <!-- FULLCALDENDAR-->
    <link href="<?php echo e(asset('splash/vendor/fullcalendar/core/main.min.css')); ?>" rel='stylesheet' />
    <link href="<?php echo e(asset('splash/vendor/fullcalendar/daygrid/main.min.css')); ?>" rel='stylesheet' />

<!-- SWEET ALERT -->
    <link href="<?php echo e(asset('splash/vendor/waitme/waitme.min.css')); ?>" rel='stylesheet' />





<body>
  
    <div id="app " class="container-fluid navegacion static-top bg-info py-3">
      
        <!-- Navigation -->

        
        <nav class=" navbar navbar-expand-lg bg-transparent   ">
            <a class="navbar-brand py-3" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('splash/img/logowhite.png')); ?>" class="logo">
            </a>                

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon text-light"><i class="fas fa-bars"></i></span>
            </button>



            <div class="collapse navbar-collapse text-center text-md-left" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav  ml-md-auto">
                    <?php if(Auth::check()): ?>   <!-- Si el usuario ha iniciado sesión se mostrará esto: -->

                    <!-- Sólo los administradores pueden ´ver Doctores y Consultorios -->
                    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(action('DoctorController@index')); ?>"><i class="icon fas fa-user-md"></i> <?php echo e(__('Doctores')); ?></a>
                    </li>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(action('PatientController@index')); ?>"> <i class="icon fas fa-user-injured"></i> <?php echo e(__('Pacientes')); ?></a>
                    </li>

                    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(action('OfficeController@index')); ?>"><i class="icon fas fa-hospital"></i> <?php echo e(__('Consultorios')); ?></a>
                    </li>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(action('AppointmentController@index')); ?>"><i icon class="fas fa-book"></i> <?php echo e(__('Citas')); ?></a>
                    </li>

                    <?php endif; ?>
                </ul>

                <!-- Lado derecho de navbar -->
                <ul class="navbar-nav ml-md-3">
                    <!-- Auth -->
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" onclick="esperar()" href="<?php echo e(route('login')); ?>"><i class="fas icon fa-sign-in-alt"></i> <?php echo e(__('Iniciar sesión')); ?></a>
                    </li>
                    <li class="nav-item">
                        <?php if(Route::has('register')): ?>
                        <a class="nav-link" onclick="esperar()" href="<?php echo e(route('register')); ?>"><i class="fas icon fa-user-plus"></i> <?php echo e(__('Registrarse')); ?></a>
                        <?php endif; ?>
                    </li>
                    <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <i class="icon fas fa-user"></i> <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="esperar(); event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <i class="fas icon fa-sign-out-alt"></i> <?php echo e(__('Cerrar sesión')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                <?php endif; ?>
            </ul>
        </div>

    </nav>

    
</div>

<main class="">
    <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>

</main>

<script src="<?php echo e(asset('splash/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('splash/vendor/jquery/picker.js')); ?>"></script>
<script src="<?php echo e(asset('splash/vendor/jquery/picker.date.js')); ?>"></script>
<script src="<?php echo e(asset('splash/vendor/jquery/picker.time.js')); ?>"></script>

<script src="<?php echo e(asset('splash/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('splash/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('splash/vendor/fullcalendar/core/main.min.js')); ?>"></script>
      <script src="<?php echo e(asset('splash/vendor/fullcalendar/daygrid/main.min.js')); ?>"></script>
          <script src="<?php echo e(asset('splash/vendor/fullcalendar/core/moment/main.min.js')); ?>"></script>
    <script src="<?php echo e(asset('splash/vendor/fullcalendar/interaction/main.min.js')); ?>"></script>

<script src="<?php echo e(asset('splash/vendor/waitme/waitme.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>

  
</body>

</html>
