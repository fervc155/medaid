<?php $__env->startSection('content'); ?>



<div class="tabmenu">
	<div class="row justify-content-center">
		

		<ul class="nav  md-tabs" id="Tabmenu" role="tablist">
			<li>
				<a class="nav-link active " id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
				aria-selected="false"><i class="fas d-md-inline-block d-none fa-user-injured"></i><i class="fas d-md-none d-inline-block fa-calendar"></i><span> Mis Datos</span></a>
			</li>

			<li class="d-block d-md-none">
				<a class="nav-link "  onclick="cambiardehoja()" id="calendario-tab" data-toggle="tab" href="#calendario" role="tab" aria-controls="calendario"
				aria-selected="false"><i class="fas fa-user-md"></i><span> Calendario</span></a>
			</li>

			<li class="nav-item">
				<a class="nav-link" id="citas-tab" data-toggle="tab" href="#citas" role="tab" aria-controls="citas"
				aria-selected="false"><i class="fas fa-book"></i> <span> Citas</span></a>
			</li>
		</ul>
	</div>
</div>


<div class="container mt-5">
	

	<div class="tab-content " id="TabContenido">


		<div class="tab-pane   fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

			
			<div class="row row-datos d-inline d-md-none  text-center contadores">
				<div class="col-auto ">

					<div class="caja">

						<?php $i=0; 

						foreach ($appointments as $a)
						{
							if ($a->completed == false)
							{
								$i++;
							}
						}  

						?>
						<i class="fas fa-book"></i>
						<div class="texto">


							<h3><?php echo e($i); ?></h3>
							<p>Citas</p>	
						</div>
					</div>


				</div>

				

			</div>

			<div class="row ">


				<div id="col-datos" class=" col-12 d-none d-md-block col-md-4">




					<div class="card box-shadow lead">


						<div class="rounded">
							<div class="bg-primary text-center p-5">
								<i class="fas fa-user-injured display-1 text-light"></i>
							</div>
						</div>


						<h5 class="card-header h4 text-light bg-secondary text-center text-capitalize"><i class="fas fa-user-md"></i> <?php echo e($patient->name); ?></h5>

						<div class="card-body">






							<div class="form-inline mb-2">


								<div class="color-principal">

									<i class="fas fa-id-card"></i> DNI: 
								</div>  

								<?php echo e($patient->dni); ?>


							</div>

							<div class="form-inline mb-2">
								<div class="color-principal">
									<i class="fas fa-id-card"></i> CURP:
								</div>

								<?php echo e($patient->curp); ?>


							</div>
							<div class="form-inline mb-2">


								<div class="color-principal">

									<i class="fas fa-phone"></i> Telefono:
								</div>  

								<?php echo e($patient->telephoneNumber); ?>


							</div>


							
							<div class="form-inline mb-2">
								<div class="color-principal">
									<i class="fas fa-birthday-cake"></i> Nacimiento:
								</div>                                  
								<?php echo e($patient->birthdate); ?>


							</div>



							<div class="form-inline mb-2">
								<div class="color-principal">
									<i class="fas fa-venus-mars"></i> Sexo:
								</div>
								<?php echo e($patient->sex); ?>


							</div>


							<div class="form-inline mb-2">
								<div class="color-principal">
									<i class="fas fa-home"></i> Domicilio: 
								</div>



								<?php echo e($patient->address); ?>



							</div>

							<div class="form-inline mb-2">
								<div class="color-principal">
									<i class="fas fa-envelope"></i> CP: 
								</div>



								<?php echo e($patient->cp); ?>



							</div>

							<div class="form-inline mb-2">
								<div class="color-principal">
									<i class="fas fa-city"></i> Ciudad: 
								</div>



								<?php echo e($patient->city); ?>



							</div>

							<div class="form-inline mb-2">
								<div class="color-principal">
									<i class="fas fa-flag"></i> Pais: 
								</div>



								<?php echo e($patient->country); ?>



							</div>



							<div class="form-inline mb-3">
								<div class="color-principal">
									<i class="fas fa-user-tie"></i> Doctor:
								</div>



								<a href="/doctor/<?php echo e($patient->doctor->id); ?>" class="link"><?php echo e($patient->doctor->name); ?></a>


							</div>  
							<a role="button" class="btn btn-wait btn-block mt-3  btn-info" href="/patient/<?php echo e($patient->dni); ?>/edit"> <i class="fas fa-pen"></i> Editar</a>

							<a role"button" class="btn btn-block btn-danger text-light mt-3 " onclick="btn_confirm_delete()"> <i class="fas fa-trash"></i> Eliminar</a>

							
							<?php echo Form::open(['action' => ['PatientController@destroy', $patient->dni], 'method' => 'POST']); ?>

							<?php echo e(Form::hidden('_method', 'DELETE')); ?>

							<?php echo e(Form::submit('Eliminar', ['class' => 'd-none  btn-delete'])); ?>

							<?php echo Form::close(); ?>


						</div>

					</div>

				</div>

				<div class=" col-12 col-md-8 ">



					<div class=" row  text-center contadores">
						<div class="col  d-none d-md-block">

							<div class="caja">

								<?php $i=0; 

								foreach ($appointments as $a)
								{
									if ($a->completed == false)
									{
										$i++;
									}
								}  

								?>
								<i class="fas fa-book"></i>
								<div class="texto">
									

									<h3><?php echo e($i); ?></h3>
									<p>Citas</p>	
								</div>
							</div>


						</div>

						
					</div>


					<div class="row mt-3">
						<div class="col d-none">
							<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($a->completed == false): ?>

							<span class="citas-fecha"><?php echo e($a->date); ?></span>

							<span class="citas-hora"><?php echo e($a->time); ?></span>
							<span class="citas-descripcion"><?php echo e($a->description); ?></span>
							<span class="citas-paciente"><?php echo e($a->patient->name); ?></span>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
						<div class="col p-3 ">
							<div id='calendar'></div>

						</div>

					</div>








				</div>
			</div>


		</div>



		<div class="tab-pane   fade show " id="citas" role="tabpanel" aria-labelledby="citas-tab">

			<div class="row">


				<div class="col tarjeta">

					<div class="row ">
						<section class="col-12 pb-3">
							<h5 class="text-center h1 color-principal text-capitalize"><i class="fas fa-book"></i> Citas</h5>
						</section>
					</div>
					<div class="row ">
						<div class="col-12 p-0 ">



							<?php if(count($appointments)>0): ?>
							<div class="d-none d-md-block tarjeta-contenido-blanco ">
								<table class="table ">
									<thead>
										<tr>
											<th>Fecha</th>
											<th>Hora</th>
											<th>Costo</th>
											<th>Razón</th>
											<th>Consultorio</th>
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($a->completed == false): ?>
										<tr>
											<td><a class="link" href="/appointment/<?php echo e($a->id); ?>"><?php echo e($a->date); ?></a></td>
											<td><?php echo e($a->time); ?></td>
											<td><?php echo e($a->cost); ?></td>
											<td><?php echo e($a->description); ?></td>
											<td><a class="link" href="/office/<?php echo e($a->office->id); ?>"><?php echo e($a->office->name); ?></a></td>
										</tr>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>




							<div class="d-block    d-md-none">
								<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($appointment->completed == false): ?>
								

								<div class="card  tarjeta my-3">

									<p class="lead bg-primary text-light card-header card-title"> <i class="fas fa-calendar-week"></i> <?php echo e($appointment->date); ?></p>

									<div class="card-body">


										<div class="form-inline mb-2">


											<div class="icon-form">

												<i class="fas fa-clock"></i> 
											</div>	
											<div class="icon-texto">
												<span class="color-principal">Hora </span> <?php echo e($appointment->time); ?>

											</div>
										</div>


										<div class="form-inline mb-2">
											<div class="icon-form">
												<i class="fas fa-money-bill-wave"></i>
											</div>

											<div class="icon-texto">

												<span class="color-principal">Costo </span> <?php echo e($appointment->cost); ?>

											</div>

										</div>


										<div class="form-inline mb-2">
											<div class="icon-form">
												<i class="fas fa-tag"></i>
											</div>

											<div class="icon-texto">

												<span class="color-principal">Descripcion </span> <?php echo e($appointment->description); ?>

											</div>

										</div>


										

										<div class="form-inline mb-3">
											<div class="icon-form">
												<i class="fas fa-user-md"></i>
											</div>

											<div class="icon-texto">

												<span class="color-principal">Especialidad: </span><a class="link" href="/office/<?php echo e($a->office->id); ?>"> <?php echo e($appointment->office->name); ?></a>
											</div>
										</div>
										<a href="/appointment/<?php echo e($appointment->id); ?>" class=" btn btn-wait btn-primary btn-block"><i class="fas fa-eye"></i> Ver mas</a>

									</div>

								</div>
								<?php endif; ?>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>


							<?php else: ?>
							<p class="lead p-3">No se encontraron citas. <a class="link" href="/appointment/create">¡Agenda una!</a></p>

							<?php endif; ?>



						</div> 

					</div> 

				</div>
			</div>




		</div>



		<div class="tab-pane     fade show " id="calendario" role="tabpanel" aria-labelledby="calendario-tab">


			<div class="row">		
				
				<div class="col" id="col-datos2">
					
				</div>
			</div>



		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>