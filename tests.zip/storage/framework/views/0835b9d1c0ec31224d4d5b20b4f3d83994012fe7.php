<?php $__env->startSection('content'); ?>
<section class="container tarjeta">

    <div class="row justify-content-center">
        <div class="col-12 col-md-6 tarjeta-titulo">
            <h2 class="h2"><?php echo e(__('Restablecer contraseña')); ?></h2>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-12 col-md-6 tarjeta-contenido ">
            
   
                   <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group form-inline justify-content-center">

                            <div class="icon-form ">
                                <i class="fas fa-at"></i>
                            </div>

                       
                                <input id="email" type="email" class="form-control-claro form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Correo electrónico')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>

                        <div class="form-group form-inline justify-content-end mb-0">
                                <button type="submit" class="btn btn-primary btn-claro">
                                    <?php echo e(__('Enviar enlace de recuperación')); ?>

                                </button>
                            </div>
                    </form>
             
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>