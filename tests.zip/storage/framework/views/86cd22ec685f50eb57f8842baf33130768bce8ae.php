<?php $__env->startSection('content'); ?>


<div class="contenedor">
		
	<div class="contenedor-titulo hidden-lg-down">
		
		<section class="container m-0  p-0">

			<div class="row contenedor-titulo align-items-center">
				<div class="col ">

						<h1 class="display-4 text-capitalize  text-center">médicos</h1> 
					
				</div>
			</div>



		</section>
	</div>

	<div class="contenedor-fondo">
		
	</div>

	<div class="contenedor-imagen">
		
		<div class="container-fluid mt-0  p-0">

			<div class="row ">
				<div class="col ">

						<img src="<?php echo e(asset('splash/header/doctor.jpg')); ?>"> 
					
				</div>
			</div>



		</div>
	</div>

</div>

<div class="container my-5">
	<div class="row justify-content-end">
		<div class="col-12 col-md-4">
			
		<div class="form-group" align="center">
			<a href="/doctor/create" role="button" class="btn btn-secondary btn-block"><i class="fas fa-plus"></i> Agregar</a>
		</div>
		</div>
	</div>
</div>

<div class="container">

	<div class="row">
		<div class="col-12 table-responsive d-none d-md-block">

		<?php if(count($doctors) > 0): ?>
		<table class="table" id="data_table">
			<thead>
				<tr>
					<th >Nombre</th>
					<th >Fecha de nacimiento</th>
					<th >Teléfono</th>
					<th >Turno</th>
					<th >Sexo</th>
					<th >Cédula</th>
					<th >Especialidad</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					
					<td><a class="link" href="/doctor/<?php echo e($d->id); ?>"><?php echo e($d->name); ?></a></td>
					<td><?php echo e($d->birthdate); ?></td>
					<td><?php echo e($d->telephoneNumber); ?></td>
					<td><?php echo e($d->turno); ?></td>
					<td><?php echo e($d->sexo); ?></td>
					<td><?php echo e($d->cedula); ?></td>
					<td><?php echo e($d->especialidad); ?></td>
					
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		<?php else: ?>
		<p class="lead">No se encontraron doctores. <a href="/doctor/create">¡Agrega uno!</a></p>
		<?php endif; ?>
		</div>
		<div class="col-12 d-block d-md-none">


		<?php if(count($doctors)>0): ?>



			<?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="card tarjeta  my-3">

					<p class="lead bg-primary text-light card-header card-title"> <i class="fas fa-user-md"></i> <?php echo e($doctor->name); ?></p>

					<div class="card-body">
						
						

						<div class="form-inline mb-2">
							
								
							<div class="icon-form">
								
								<i class="fas fa-phone"></i> 
							</div>	
							<div class="icon-texto">
								<span class="color-principal">Teléfono: </span> <?php echo e($doctor->telephoneNumber); ?>

							</div>
						</div>

						<div class="form-inline mb-2">
							<div class="icon-form">
								<i class="fas fa-sun"></i>
							</div>

							<div class="icon-texto">
								
								 <span class="color-principal">Turno: </span> <?php echo e($doctor->turno); ?>

							</div>
							
				</p>		</div>


						<div class="form-inline mb-2">
							<div class="icon-form">
								<i class="fas fa-venus-mars"></i>
							</div>

							<div class="icon-texto">
								
								 <span class="color-principal">Sexo: </span> <?php echo e($doctor->sexo); ?>

							</div>
							
						</div>


						<div class="form-inline mb-2">
							<div class="icon-form">
								<i class="fas fa-address-card"></i>
							</div>

							<div class="icon-texto">
								
								 <span class="color-principal">Cedula: </span> <?php echo e($doctor->cedula); ?>

							</div>
							
						</div>


						<div class="form-inline mb-3">
							<div class="icon-form">
								<i class="fas fa-user-tie"></i>
							</div>

							<div class="icon-texto">
								
								 <span class="color-principal">Especialidad: </span> <?php echo e($doctor->especialidad); ?>

							</div>
							
						</div>	
					<a href="/doctor/<?php echo e($doctor->id); ?>" class=" btn btn-primary btn-block"><i class="fas fa-eye"></i> Ver mas</a>
					</div>
						
				</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
				
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.dataTables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>