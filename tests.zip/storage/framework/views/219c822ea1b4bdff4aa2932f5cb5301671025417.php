<?php $__env->startSection('content'); ?>

<div class="contenedor">
		
	<div class="contenedor-titulo hidden-lg-down">
		
		<section class="container m-0  p-0">

			<div class="row contenedor-titulo align-items-center">
				<div class="col ">

						<h1 class="display-4 text-capitalize  text-center">Consultorios</h1> 
					
				</div>
			</div>



		</section>
	</div>

	<div class="contenedor-fondo">
		
	</div>

	<div class="contenedor-imagen">
		
		<div class="container-fluid mt-0  p-0">

			<div class="row ">
				<div class="col ">

						<img src="<?php echo e(asset('splash/header/consultorio.jpg')); ?>"> 
					
				</div>
			</div>



		</div>
	</div>

</div>

<div class="container my-5">
	<div class="row justify-content-end">
		<div class="col-12 col-md-4">
			
		<div class="form-group" align="center">
			<a href="/office/create" role="button" class="btn btn-secondary btn-block"><i class="fas fa-plus"></i> Agregar</a>
		</div>
		</div>
	</div>
</div>


<div class="container">
	<div class="row">
		<div class="col-12 d-none d-md-inline table-responsive">
			

	<?php if(count($offices) > 0): ?>
	<table class="table " id="data_table">
		<thead>
			<tr >
			
				<th >Nombre</th>
				<th >Domicilio</th>
				<th >C.P.</th>
				<th >Ciudad</th>
				<th >País</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					
					<td><a class="link" href="/office/<?php echo e($o->id); ?>"><?php echo e($o->name); ?></a></td>
					<td><?php echo e($o->address); ?></td>
					<td><?php echo e($o->postalCode); ?></td>
					<td><?php echo e($o->city); ?></td>
					<td><?php echo e($o->country); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>
	</table>

	<?php else: ?>
		<p class="lead">No se encontraron consultorios. <a class="link" href="/office/create">¡Agrega uno!</a></p>
	<?php endif; ?>

		</div>
	<div class="col-12 d-block d-md-none">
		


	<?php if(count($offices)>0): ?>


		<?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<table class="table ">
						<tbody>
							<tr><th><i class="fas fa-id-card"></i> ID</th> <td><?php echo e($office->id); ?></td></tr>

							<tr><th><i class="fas fa-home"></i> Domicilio</th> <td><?php echo e($office->address); ?></td></tr>

							<tr><th><i class="fas fa-envelope"></i> CP</th> <td> <?php echo e($office->postalCode); ?></td></tr>
							
							<tr><th><i class="fas fa-city"></i> Ciudad</th> <td> <?php echo e($office->city); ?></td></tr>

						

							<tr><th><i class="fas fa-flag"></i> Pais</th> <td> <?php echo e($office->country); ?></td></tr>

							
						</tbody>
					</table>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>


		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.dataTables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>