<?php $__env->startSection('content'); ?>
<secton class="container tarjeta ">
    <div class="row justify-content-center ">
        <div class=" text-center tarjeta-titulo col-12 col-md-6  ">
            <h2 class="h2 py-3 m-0">
                <?php echo e(__('Iniciar Sesion')); ?>

                
            </h2>
        </div>
    </div>
    <div class="row  justify-content-center">


        <div class="tarjeta-contenido col-md-6 col-12">
               
            <form method="POST"  action="<?php echo e(route('login')); ?>" >
                <?php echo csrf_field(); ?>

                <div class="form-group form-inline tarjeta-formulario justify-content-center">
                
                    <div class="icon-form">
                        <i class="fas fa-at"></i>
                    </div>

                        <input id="email" type="email" class="form-control-claro form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="<?php echo e(__('Correo Electronico')); ?>">

                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback text-light" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                   
                </div>

                <div class="form-group form-inline tarjeta-formulario justify-content-center">
                    <div class="icon-form ">
                       <i class="fas fa-key"></i>
                    </div>
                    
                        <input id="password" type="password" class="form-control-claro form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="<?php echo e(__('Clave')); ?>">

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback text-light" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                </div>
            
                <div class="my-5">
                    
                    <button type="submit" class="btn  w-100 btn-claro">
                        <?php echo e(__('Entrar')); ?>

                    </button>
                </div>
                    
                <div class="form-group  form-inline justify-content-between">
                   
                            
            
     
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                        <label class="form-check-label  link-blanco lead" for="remember">
                            <?php echo e(__('Recordarme')); ?>

                        </label>
                    </div>
             

                <div class="form-inline justify-content-end">
                    <a class="link-blanco  lead" href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

                            </a>
                </div>
                </div>
            </form>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>