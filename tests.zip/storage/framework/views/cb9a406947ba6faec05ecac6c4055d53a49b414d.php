<?php $__env->startSection('content'); ?>
<div class="container tarjeta">
    <div class="row justify-content-center">
        <div class="col-md-6 col-12 tarjeta-titulo">
            <h2 class="h2 ">Dashboard</h2>
        </div>
    </div>
    <div class="row justify-content-center">
        
        <div class="col-12 col-md-6 tarjeta-contenido ">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="text-light lead text-center">
            Iniciaste sesión sin problemas!
                
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>