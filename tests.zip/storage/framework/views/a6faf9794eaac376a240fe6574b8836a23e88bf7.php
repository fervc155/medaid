<?php $__env->startSection('content'); ?>

<div class="contenedor">
		
	<div class="contenedor-titulo hidden-lg-down">
		
		<section class="container m-0  p-0">

			<div class="row contenedor-titulo align-items-center">
				<div class="col ">

						<h1 class="display-4 text-capitalize  text-center"><?php echo e($patient->name); ?></h1> 
						<h3 class="text-center text-capitalize">Paciente</h3>
					
				</div>
			</div>



		</section>
	</div>

	<div class="contenedor-fondo">
		
	</div>

	<div class="contenedor-imagen">
		
		<div class="container-fluid mt-0  p-0">

			<div class="row ">
				<div class="col ">

						<img src="<?php echo e(asset('splash/header/paciente.jpg')); ?>"> 
					
				</div>
			</div>



		</div>
	</div>

</div>


<div class="container-fluid tabmenu pl-5 ">
	<div class="row justify-content-center">
		
	
		<ul class="nav  md-tabs" id="Tabmenu" role="tablist">
		  <li class="nav-item">
		    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
		      aria-selected="true"><i class="fas fa-user-md"></i> Mis Datos</a>
		  </li>
		
		  <li class="nav-item">
		    <a class="nav-link" id="citas-tab" data-toggle="tab" href="#citas" role="tab" aria-controls="citas"
		      aria-selected="false"><i class="fas fa-book"></i> Citas</a>
		  </li>
		</ul>
	</div>
</div>



<div class="tab-content container  pt-5 mb-5" id="TabContenido">
  <div class="tab-pane row justify-content-center fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

		<div class="col-12 tarjeta">
			<div class="row tarjeta-titulo">
					
				<div class="col ">
						
					<h5 class="text-center text-capitalize"><i class="fas fa-user-injured"></i> Datos del paciente</h5>
				</div>
			</div>
			<div class="row tarjeta-contenido-blanco p-3">
				
				<table class="table">
						<tbody>
							<tr><th><i class="fas fa-id-card"></i> DNI</th> <td><?php echo e($patient->dni); ?></td></tr>

							<tr><th><i class="fas fa-id-card"></i> CURP</th> <td><?php echo e($patient->curp); ?></td></tr>

							<tr><th><i class="fas fa-birthday-cake"></i> Fecha de nacimiento:</th> <td> <?php echo e($patient->birthdate); ?></td></tr>
							<tr><th><i class="fas fa-phone"></i> Teléfono</th> <td> <?php echo e($patient->telephoneNumber); ?></td></tr>

						
							<tr><th><i class="fas fa-venus-mars"></i> Sexo</th> <td> <?php echo e($patient->sex); ?></td></tr>

							<tr><th><i class="fas fa-address-card"></i> Domicilio</th> <td> <?php echo e($patient->address); ?></td></tr>

							<tr><th><i class="fas fa-envelope"></i> CP</th> <td> <?php echo e($patient->postalCode); ?></td></tr>

							<tr><th><i class="fas fa-city"></i> Ciudad</th> <td> <?php echo e($patient->city); ?></td></tr>

							<tr><th><i class="fas fa-flag"></i> Pais</th> <td> <?php echo e($patient->country); ?></td></tr>

							<tr><th><i class="fas fa-flag"></i> Medico</th> <td><a href="/doctor/<?php echo e($doctor->id); ?>"> <?php echo e($doctor->name); ?></a></td></tr>

						</tbody>
					</table>
						
			
			</div>
			<div class="row tarjeta-contenido-blanco align-items-center py-3 ">

			
				<div class="col-12 col-md-6">
					<a role="button" class="btn btn-block btn-primary" href="/patient/<?php echo e($patient->dni); ?>/edit"><i class="fas fa-pen"></i> Editar</a>
					
				</div>
	
				<div class="col-12 col-md-6">
					<?php echo Form::open(['action' => ['PatientController@destroy', $patient->dni], 'method' => 'POST']); ?>

					<?php echo e(Form::hidden('_method', 'DELETE')); ?>

					<?php echo e(Form::submit('Eliminar', ['class' => 'btn btn-block btn-danger'])); ?>

					<?php echo Form::close(); ?>

				</div>
			</div>

		</div>
	
	


  </div>



  <div class="tab-pane fade row justify-content-center" id="citas" role="tabpanel" aria-labelledby="citas-tab">
		
	<div class="col-12 tarjeta">
		
		<div class="row tarjeta-titulo">
			<div class="col-12">
				<h5 class="text-center text-capitalize"><i class="fas fa-book"></i> Citas pendientes</h5>
			</div>
		</div>
		<div class="row tarjeta-contenido-blanco">
			<div class="col-12 p-0 ">
				<table class="table ">
				<thead>
					<tr>
						<th >Fecha</th>
						<th >Hora</th>
						<th >Costo</th>
						<th >Razón</th>
						<th >Consultorio</th>
						<th >Atender</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($a->completed == false): ?>
					<tr>
						<td><a href="/appointment/<?php echo e($a->id); ?>"><?php echo e($a->date); ?> </a></td>
						<td><?php echo e($a->time); ?></td>
						<td><?php echo e($a->cost); ?></td>
						<td><?php echo e($a->description); ?></td>
						<td><?php echo e($a->office->name); ?></td>
						<td>
							<?php echo Form::open(['action' => ['AppointmentController@complete', $a->id], 'method' => 'PATCH']); ?>

							<?php echo e(Form::hidden('_method', 'PATCH')); ?>

							<?php echo e(Form::submit('Atender', ['class' => 'btn btn-success'])); ?>

							<?php echo Form::close(); ?>

						</td>
					</tr>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			</div> <!--Card-->
		</div> <!--Row-->

	</div> <!--Card-->




  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>