<?php $__env->startSection('content'); ?>
<section class="container my-5">
    <div class="row">
        <div class="col">
            
            <h1 class="text-center display-4 text-capitalize color-principal">Editar Paciente</h1>
        </div>
    </div>
</section>
<div class="container tarjeta">
  <div class="row justify-content-center">

   

    <div class="col-md-6 col-12">

      <?php echo Form::open(['action' => ['PatientController@update', $patient->dni], 'method' => 'PUT']); ?>

      <div class="form-group form-inline">
         <div class="icon-form">
                    <i class="fas fa-user"></i>
          </div>
       <?php echo e(Form::text('name', $patient->name, ['class'=>'form-control', 'placeholder' => 'Nombre'] )); ?>

     </div>
     <div class="form-group form-inline">
        <div class="icon-form">
          <i class="fas fa-id-card"></i>
        </div>

       <?php echo e(Form::text('curp', $patient->curp, ['class'=>'form-control', 'placeholder' => 'CURP'] )); ?>

     </div>
     <div class="form-group form-inline">
      <div class="icon-form">
                    <i class="fas fa-birthday-cake"></i>
                </div>

      <?php echo e(Form::date('birthdate', $patient->birthdate, ['class'=>'form-control', 'placeholder' => 'Fecha de nacimiento'] )); ?>

    </div>
    <div class="form-group form-inline">
      <div class="icon-form">
                    <i class="fas fa-phone"></i>
          </div>
     <?php echo e(Form::text('telephoneNumber', $patient->telephoneNumber, ['class'=>'form-control', 'placeholder' => 'Número telefónico'] )); ?>

   </div>
   <div class="form-group form-inline">
    <div class="icon-form">
                    <i class="fas fa-venus-mars"></i>
          </div>
     <?php echo e(Form::select('sex', ['M' => 'M', 'F' => 'F'], null , ['class'=> 'form-control'])); ?>

   </div>
   <div class="form-group form-inline">
    <div class="icon-form">
                    <i class="fas fa-home"></i>
          </div>
      <?php echo e(Form::text('address', $patient->address, ['class'=>'form-control', 'placeholder' => 'Calle, número y colonia'] )); ?>

    </div>
   <div class="form-group form-inline">
    <div class="icon-form">
                    <i class="fas fa-envelope"></i>
          </div>
     <?php echo e(Form::text('postalCode', $patient->postalCode, ['class'=>'form-control', 'placeholder' => 'Código Postal'] )); ?>

   </div>
   <div class="form-group form-inline">
    <div class="icon-form">
                    <i class="fas fa-city"></i>
          </div>
     <?php echo e(Form::text('city', $patient->city, ['class'=>'form-control', 'placeholder' => 'Ciudad'] )); ?>

   </div>
   <div class="form-group form-inline">
    <div class="icon-form">
                    <i class="fas fa-flag"></i>
          </div>
     <?php echo e(Form::text('country', $patient->country, ['class'=>'form-control', 'placeholder' => 'País'] )); ?>

   </div>
   <div class="form-group form-inline">
    <div class="icon-form">
                    <i class="fas fa-user-md"></i>
          </div>
     <?php echo e(Form::text('doctor_id', $patient->doctor_id, ['class'=>'form-control', 'placeholder' => 'ID del médico del paciente'] )); ?>

   </div>

   <?php echo e(Form::hidden('_method','PUT')); ?>

   <?php echo e(Form::submit('Aceptar', ['class'=>'btn btn-block btn-primary'])); ?>


   <?php echo Form::close(); ?>

 </div>


</div> <!-- Fila -->
</div> <!-- Contenedor -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>