<?php $__env->startSection('content'); ?>

<div class="contenedor">
		
	<div class="contenedor-titulo hidden-lg-down">
		
		<section class="container m-0  p-0">

			<div class="row contenedor-titulo align-items-center">
				<div class="col ">

						<h1 class="display-4 text-capitalize  text-center">Citas</h1> 
					
				</div>
			</div>



		</section>
	</div>

	<div class="contenedor-fondo">
		
	</div>

	<div class="contenedor-imagen">
		
		<div class="container-fluid mt-0  p-0">

			<div class="row ">
				<div class="col ">

						<img src="<?php echo e(asset('splash/header/citas.jpg')); ?>"> 
					
				</div>
			</div>



		</div>
	</div>

</div>


<!-- Se muestran los datos de la entidad en una tabla, utilizando formato Blade de PHP para acceder
	a cada atributo fácilmente -->

<div class="container my-5">
	<div class="row justify-content-end">
		<div class="col-12 col-md-4">
			
		<div class="form-group" align="center">
			<a href="/appointment/create" role="button" class="btn btn-secondary btn-block"><i class="fas fa-book"></i> Agendar</a>
		</div>
		</div>
	</div>
</div>


<div class="container">


	<div class="row">
		<div class="col-12 table-responsive d-none d-md-block">
			

			<!-- Si el número de citas es mayor a cero, se mostrarán los datos -->
			<?php if(count($appointments) > 0): ?>
			<table class="table " id="data_table">
				<thead>
					<tr>
						<th >Fecha</th>
						<th >Hora</th>
						<th >Costo</th>
						<th >Razón</th>
						<th >Médico</th>
						<th >Paciente</th>
						<th >Consultorio</th>
						<th >¿Completada?</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><a class="link" href="/appointment/<?php echo e($a->id); ?>"><?php echo e($a->date); ?></a></td>
							<td><?php echo e($a->time); ?></td>
							<td>$<?php echo e($a->cost); ?> MXN</td>
							<td><?php echo e($a->description); ?></td>
							<td><a class="link" href="/doctor/<?php echo e($a->doctor->id); ?>"><?php echo e($a->doctor->name); ?> </a></td>
							<td><a class="link" href="/patient/<?php echo e($a->patient->dni); ?>"><?php echo e($a->patient->name); ?> </a></td>
							<td><a class="link" href="/office/<?php echo e($a->office->id); ?>"><?php echo e($a->office->name); ?> </a></td>
							<td>
								<?php if($a->completed == true): ?>
									Sí
								<?php else: ?>
									No
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</tbody>
			</table>

			<!-- Si no hay registros, el usuario será informado -->
			<?php else: ?>
				<p class="lead">No se encontraron citas. <a class="link" href="/appointment/create">¡Agenda una!</a></p>
			<?php endif; ?>


		</div>
		<div class="col-12 d-block d-md-none">
		<?php if(count($appointments)>0): ?>
			<?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<table class="table">
						<tbody>
							<tr><th><i class="fas fa-id-card"></i> ID:</th> <td><?php echo e($appointment->id); ?></td></tr>

							<tr><th><i class="fas fa-calendar-week"></i> Fecha</th> <td> <?php echo e($appointment->date); ?></td></tr>

							<tr><th><i class="fas fa-clock"></i> Hora</th> <td> <?php echo e($appointment->time); ?></td></tr>

							<tr><th><i class="fas fa-money-bill-wave"></i>Costo</th> <td> <?php echo e($appointment->cost); ?></td></tr>

							<tr><th><i class="fas fa-tag"></i> Descripcion</th> <td> <?php echo e($appointment->description); ?></td></tr>

							<tr><th><i class="fas fa-user-md"></i> Medico</th> <td><a class="link" href="/doctor/<?php echo e($appointment->doctor_id); ?>"> <?php echo e($appointment->doctor_id); ?></a></td></tr>

							<tr><th><i class="fas fa-user-injured"></i> Paciente</th> <td><a class="link" href="/patient/<?php echo e($appointment->patient_dni); ?>"> <?php echo e($appointment->patient_dni); ?> </a></td></tr>

							<tr><th><i class="fas fa-hospital"></i> Consultorio</th> <td><a class="link" href="/office/<?php echo e($appointment->officee_id); ?>"> <?php echo e($appointment->office_id); ?></a></td></tr>

							<tr><th><i class="fas fa-quote-left"></i> Comentarios</th> <td> <?php echo e($appointment->comments); ?></td></tr>

							<?php if($appointment->completed ==1): ?>
							<tr><th><i class="fas fa-check"></i> Completada</th> <td> Si</td></tr>
							<?php else: ?>
							<tr><th><i class="fas fa-times"></i> Completada</th> <td> No</td></tr>

							<?php endif; ?>
						</tbody>
					</table>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
		</div>

	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.dataTables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>