<?php $__env->startSection('content'); ?>
<section class="container tarjeta">


    <div class="row justify-content-center ">
        <div class=" text-center tarjeta-titulo col-12 col-md-6  ">
            <h2 class="h2 py-3 m-0">
                <?php echo e(__('Registro')); ?>

                
            </h2>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="tarjeta-contenido col-md-6 col-12 ">

               
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group form-inline justity-content-center ">
                            <div class="icon-form ">
                                <i class="fas fa-user"></i>
                            </div>
                            
                                <input id="name" type="text" class=" form-control-claro form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('Nombre')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback lead text-light" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>

                        <div class="form-group form-inline justity-content-center ">
                            <div class="icon-form ">
                                <i class="fas fa-at"></i>
                            </div>

                                <input id="email" type="email" class=" form-control-claro form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>"  placeholder="<?php echo e(__('Correo electrónico')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback lead text-light" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>

                        <div class="form-group form-inline justity-content-center ">
                            <div class="icon-form ">
                                <i class="fas fa-key"></i>
                            </div>
                              <input id="password" type="password" class=" form-control-claro form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Contraseña')); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback lead text-light" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        
                        </div>

                        <div class="form-group form-inline justity-content-center ">
                            <div class="icon-form ">
                                <i class="fas fa-key"></i>
                            </div>

                                <input id="password-confirm" type="password" class=" form-control-claro form-control" name="password_confirmation" placeholder="<?php echo e(__('Confirmar contraseña')); ?>" required>
                      
                        </div>

                        <div class="form-group form-inline justity-content-center  mt-4 mb-0">
                  
                                <button type="submit" class="btn w-100 btn-claro">
                                    <?php echo e(__('Registrar')); ?>

                                </button>
                          
                        </div>
                    </form>
              
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>