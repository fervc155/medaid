<script src="<?php echo e(asset('splash/vendor/sweetalert/sweetalert.js')); ?>"></script>

<?php if(count($errors) > 0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<script >
	
	swal("Error","<?php echo e($error); ?>", 'error');
	
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>


<script >
	

	swal("Bien","<?php echo e(session('success')); ?>", 'success');
	
</script>
<?php endif; ?>

<?php if(session('error')): ?>

<script >
	
	swal("<?php echo e(session('error')); ?>","No puedes Iniciar Sesion", 'error');
	
</script>

<?php endif; ?>