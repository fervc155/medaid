<?php $__env->startSection('content'); ?>

<div class="contenedor">
		
	<div class="contenedor-titulo hidden-lg-down">
		
		<section class="container m-0  p-0">

			<div class="row contenedor-titulo align-items-center">
				<div class="col ">

						<h1 class="display-4 text-capitalize  text-center">Pacientes</h1> 
					
				</div>
			</div>



		</section>
	</div>

	<div class="contenedor-fondo">
		
	</div>

	<div class="contenedor-imagen">
		
		<div class="container-fluid mt-0  p-0">

			<div class="row ">
				<div class="col ">

						<img src="<?php echo e(asset('splash/header/paciente.jpg')); ?>"> 
					
				</div>
			</div>



		</div>
	</div>

</div>

<div class="container my-5">
	<div class="row justify-content-end">
		<div class="col-12 col-md-4">
			
		<div class="form-group" align="center">
			<a href="/patient/create" role="button" class="btn btn-secondary btn-block"><i class="fas fa-plus"></i> Agregar</a>
		</div>
		</div>
	</div>
</div>

<div class="container">

	<div class="row">
		<div class="col-12 table-responsive d-none d-md-block">
			

			<?php if(count($patients) > 0): ?>
			<table class="table" id="data_table">
				<thead>
					<tr>
						
						<th>Nombre</th>
						<th>CURP</th>
						<th>Fecha de nacimiento</th>
						<th>Teléfono</th>
						<th>Sexo</th>
						<th>Domicilio</th>
						<th>C.P.</th>
						<th>Ciudad</th>
						<th>País</th>
						<th>Médico</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><a class="link" href="/patient/<?php echo e($p->dni); ?>"><?php echo e($p->name); ?></a></td>
							<td><?php echo e($p->curp); ?></td>
							<td><?php echo e($p->birthdate); ?></td>
							<td><?php echo e($p->telephoneNumber); ?></td>
							<td><?php echo e($p->sex); ?></td>
							<td><?php echo e($p->address); ?></td>
							<td><?php echo e($p->postalCode); ?></td>
							<td><?php echo e($p->city); ?></td>
							<td><?php echo e($p->country); ?></td>
							<td> <a class="link" href="/doctor/<?php echo e($p->doctor->id); ?>"> <?php echo e($p->doctor->name); ?> </a></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</tbody>
			</table>

			<?php else: ?>
				<p class="lead">No se encontraron pacientes. <a class="link" href="/patient/create">¡Agrega uno!</a></p>
			<?php endif; ?>
		</div>
		<?php if(count($patients) > 0): ?>

		<div class="col-12 d-block d-md-none">
			<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
			<table class="table mb-5">
					<tbody>
						<tr><th><i class="fas fa-id-card"></i> DNI</th> <td><?php echo e($patient->dni); ?></td></tr>

						<tr><th><i class="fas fa-id-card"></i> CURP</th> <td><?php echo e($patient->curp); ?></td></tr>

						<tr><th><i class="fas fa-birthday-cake"></i> Fecha de nacimiento:</th> <td> <?php echo e($patient->birthdate); ?></td></tr>
						<tr><th><i class="fas fa-phone"></i> Teléfono</th> <td> <?php echo e($patient->telephoneNumber); ?></td></tr>

					
						<tr><th><i class="fas fa-venus-mars"></i> Sexo</th> <td> <?php echo e($patient->sex); ?></td></tr>

						<tr><th><i class="fas fa-address-card"></i> Domicilio</th> <td> <?php echo e($patient->address); ?></td></tr>

						<tr><th><i class="fas fa-envelope"></i> CP</th> <td> <?php echo e($patient->postalCode); ?></td></tr>

						<tr><th><i class="fas fa-city"></i> Ciudad</th> <td> <?php echo e($patient->city); ?></td></tr>

						<tr><th><i class="fas fa-flag"></i> Pais</th> <td> <?php echo e($patient->country); ?></td></tr>

						<tr><th><i class="fas fa-flag"></i> Medico</th> <td><a href="/doctor/<?php echo e($patient->doctor->id); ?>"> <?php echo e($patient->doctor->name); ?></a></td></tr>

					</tbody>
			</table>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php endif; ?>

	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.dataTables', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>